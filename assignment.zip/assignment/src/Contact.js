import React from 'react';

const Contact = () => {
  return (
    <div style={styles.container}>
      <h2>Contact Us</h2>
      <form style={styles.form}>
        <label>
          Name:
          <input type="text" />
        </label>
        <label>
          Email:
          <input type="email" />
        </label>
        <label>
          Message:
          <textarea rows="4" />
        </label>
        <button style={styles.button} type="submit">Send Message</button>
      </form>
    </div>
  );
}


export default Contact;
