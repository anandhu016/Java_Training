import React from 'react';

const Signup = () => {
  return (
    <div style={styles.container}>
      <h2>Sign Up</h2>
      <form style={styles.form}>
        <label>
          Username:
          <input type="text" />
        </label>
        <label>
          Email:
          <input type="email" />
        </label>
        <label>
          Password:
          <input type="password" />
        </label>
        <button style={styles.button} type="submit">Sign Up</button>
      </form>
    </div>
  );
}


export default Signup;
